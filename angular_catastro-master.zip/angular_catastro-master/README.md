# Angular 5 catastro
Curso de Angular en Catastro
Madrid, Diciembre 2017